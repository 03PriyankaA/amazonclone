$(function(){  //ui animations on the html page using js 
    AOS .init({
        easing:'ease',
        duration:1000,

    })
}) 